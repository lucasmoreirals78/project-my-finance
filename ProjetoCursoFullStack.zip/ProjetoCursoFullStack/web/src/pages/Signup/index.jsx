export const Signup =  () =>{
    return (
        <div>
            
      <header className="container flex justify-center max-w-3xl p-4">
        <img src="/imgs/logo.svg"/>

      </header>
        </div>
        )
}